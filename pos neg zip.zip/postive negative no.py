#To check if the entered number is +ve or -ve & display an correct message

num=float(input("Enter a number:"))
if num >= 0:
    print("positive or zero")
else:
    print("Negative number")
